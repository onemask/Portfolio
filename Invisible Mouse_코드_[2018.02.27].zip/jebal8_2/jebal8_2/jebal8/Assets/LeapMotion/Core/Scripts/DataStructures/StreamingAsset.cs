﻿using System;
using UnityEngine;

namespace Leap.Unity {

  [Serializable]
  public class StreamingAsset : StreamingFolder, ISerializationCallbackReceiver { }
}
