Due to the Unity package importer being strictly additive and not handling file deletions, renames, or moves well; we recommend you fully delete your Assets/LeapMotion/Core folder before importing this updated package into your project. This will also be a  requirement for future projects.

We recommend that any new prefabs or scripts you write be stored outside Leap Motion folders to make these updates easier.

Please feel free to reach out with any questions on the LeapMotion developer forums at: https://community.leapmotion.com/c/development